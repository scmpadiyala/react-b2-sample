import React, { Component } from "react";

class ResearchHome extends Component {
  state = { researchStatus: "In Approval" };

  constructor() {
    super();
    console.log("1. Constructor");
  }

  componentWillMount() {
    console.log("2. Component Will Mount");
  }

  componentDidMount() {
    console.log("4. Coponent did mount");
    this.setState({ researchStatus: "Work in progress" });
  }

  /*
   * Event Handling using arrow function (other way to is using bining)
   */
  handleProjStatus = e => {
    console.log("Project Status : " + e.target.value);
    this.setState({ researchStatus: e.target.value });
  };

  render() {
    console.log("3. Component render : " + this.state.researchStatus);
    return (
      <div>
        <h3> Welcome to my research project {this.props.projName} </h3> <br />
        <p>
          <b> {this.props.projName} </b> is a new project sponsered by Central
          Govt. of India. <br /> <br />
          Current status of this project is -{" "}
          <i> {this.state.researchStatus}</i> <br />
          <br /> <br />
          Project Status :{" "}
          <input type="text" onChange={this.handleProjStatus} />
        </p>
      </div>
    );
  }
}

export default ResearchHome;
