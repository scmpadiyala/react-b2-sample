
import {addition} from "./02_functionsample";
import Student from "./03_classtypes";

console.log("Sum of 10, 15 is : " + addition(10,15));

let ukgStudent = new Student();
ukgStudent.displayStudentInfo();